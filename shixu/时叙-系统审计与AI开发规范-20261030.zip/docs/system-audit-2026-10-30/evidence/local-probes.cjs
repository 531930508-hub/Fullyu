/* 本地防御性审计：只创建临时合成数据，仅监听127.0.0.1；不接受外部BASE/数据库参数。
 * 从项目根执行：node docs/system-audit-2026-10-30/evidence/local-probes.cjs
 * 前置：shared/integrations/server已构建。输出仅含状态与布尔证据，不含令牌/密码/顾客信息。
 * 此脚本验证当前缺陷是否存在，不是“上线验收通过”测试。
 */
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const crypto = require('node:crypto');
const { execFileSync } = require('node:child_process');
const { createRequire } = require('node:module');
const root = path.resolve(__dirname, '../../..');
const server = path.join(root, 'apps/server');
const req = createRequire(path.join(server, 'package.json'));
const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'teahour-defensive-audit-'));
const env = {
  ...process.env,
  DATABASE_URL: `file:${path.join(temp, 'audit.db')}`,
  JWT_SECRET: crypto.randomBytes(48).toString('hex'),
  INTEGRATIONS_MODE: 'mock',
  UPLOAD_ROOT: path.join(temp, 'uploads'),
  SEED_TRANSACTIONS: '0',
  SEED_FORCE: '0',
  SEED_PASSWORD: crypto.randomBytes(24).toString('hex')
};
Object.assign(process.env, env);
let app;
const results = [];
function evidence(id, observed) { results.push({ id, ...observed }); }
(async () => {
  execFileSync(process.execPath, [req.resolve('prisma/build/index.js'), 'migrate', 'deploy'], { cwd: server, env, stdio: 'pipe' });
  execFileSync(process.execPath, [path.join(server, 'node_modules/tsx/dist/cli.mjs'), 'prisma/seed.ts'], { cwd: server, env, stdio: 'pipe' });
  req('reflect-metadata');
  const { NestFactory } = req('@nestjs/core');
  const { AppModule, jwtSecret } = req('./dist/app.module.js');
  const { ApiExceptionFilter } = req('./dist/common/api-exception.filter.js');
  const { PrismaService } = req('./dist/common/prisma.service.js');
  app = await NestFactory.create(AppModule, { logger: false });
  app.setGlobalPrefix('api');
  app.useGlobalFilters(new ApiExceptionFilter());
  await app.listen(0, '127.0.0.1');
  const base = `http://127.0.0.1:${app.getHttpServer().address().port}/api`;
  async function http(method, route, body, token) {
    const res = await fetch(base + route, { method, headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) }, ...(body === undefined ? {} : { body: JSON.stringify(body) }), signal: AbortSignal.timeout(10000) });
    return { status: res.status, body: await res.json() };
  }
  const a = await http('POST', '/customer/session', { name: '隔离审计顾客' });
  const b = await http('POST', '/customer/session', { memberCode: a.body.customer.memberCode });
  const modified = await http('PUT', '/customer/profile', { name: '隔离审计改名' }, b.body.token);
  const owner = await http('GET', '/customer/me', undefined, a.body.token);
  evidence('SEC-01', { scenario: '只持有会员码的新会话可更改原顾客资料', sessionStatus: b.status, sameCustomer: a.body.customer.id === b.body.customer.id, writeStatus: modified.status, originalSessionSeesChange: owner.body.customer.name === '隔离审计改名' });
  const menu = await http('GET', '/customer/bootstrap?storeId=sh');
  evidence('SEC-02', { scenario: '未登录顾客目录包含成本字段', httpStatus: menu.status, productCostField: menu.body.products.some(p => Object.hasOwn(p, 'costCents')), retailCostField: menu.body.retail.some(p => Object.hasOwn(p, 'costCents')) });
  const credentials = { username: '13800000004', password: env.SEED_PASSWORD };
  const login = await http('POST', '/auth/login', credentials);
  const prisma = app.get(PrismaService);
  const bcrypt = req('bcryptjs');
  await prisma.user.update({ where: { username: credentials.username }, data: { passwordHash: bcrypt.hashSync('audit-replacement-only', 10) } });
  const oldToken = await http('GET', '/auth/me', undefined, login.body.token);
  evidence('SEC-03', { scenario: '数据库密码重置后旧员工令牌仍可使用', httpStatus: oldToken.status });
  const keptSecret = process.env.JWT_SECRET;
  const keptMode = process.env.NODE_ENV;
  delete process.env.JWT_SECRET;
  process.env.NODE_ENV = 'production';
  evidence('OPS-01', { scenario: '生产环境缺JWT配置没有启动拒绝函数', fallbackStillReturned: typeof jwtSecret() === 'string' && jwtSecret().length > 0 });
  process.env.JWT_SECRET = keptSecret;
  if (keptMode === undefined) delete process.env.NODE_ENV; else process.env.NODE_ENV = keptMode;
  const { loadIntegrationsConfig } = req('@teahour/integrations');
  evidence('OPS-02', { scenario: 'NODE_ENV=production且未指定渠道模式', actualMode: loadIntegrationsConfig({ uploadRoot: temp, assetUrl: k => k, env: { NODE_ENV: 'production' } }).mode });
  // 以下为服务层故障序列注入，不代表真实支付回调或设备已经联调。
  const { OrdersService } = req('./dist/orders/orders.service.js');
  const { StaffService } = req('./dist/auth/staff.service.js');
  const orders = app.get(OrdersService);
  const account = await prisma.user.findUnique({ where: { username: credentials.username } });
  const staff = await app.get(StaffService).load(account.id);
  const tea = await prisma.product.findFirst({ where: { kind: 'tea', status: 'published', doseG: { gt: 0 } } });
  const input = { storeId: 'sh', business: 'fresh', channel: 'mini', type: 'takeaway', customerId: a.body.customer.id, items: [{ productId: tea.id, qty: 1, temp: '热', ice: '标准冰' }] };
  const mixed = await orders.createOrder({ ...input, items: [...input.items, { productId: tea.id, qty: 1, temp: '冰', ice: '少冰' }] });
  const mixedLines = await prisma.orderItem.findMany({ where: { orderId: mixed.order.id } });
  evidence('TX-13', { scenario: '同一茶饮热饮和冰饮两行被合并', layer: 'service+database', submittedLineCount: 2, storedLineCount: mixedLines.length, storedTotalQty: mixedLines.reduce((n, x) => n + x.qty, 0), retainedDistinctOptions: new Set(mixedLines.map(x => `${x.temp}/${x.ice}`)).size });
  const jobsBefore = await prisma.printJob.count({ where: { orderId: mixed.order.id } });
  await orders.markPaid(mixed.order.id, 'AUDIT-DUPLICATE-NO-EXTERNAL');
  evidence('TX-06', { scenario: '重复支付成功处理增加打印任务但没有重复销售台账', layer: 'service+database', jobsBefore, jobsAfter: await prisma.printJob.count({ where: { orderId: mixed.order.id } }), saleEntries: await prisma.financeEntry.count({ where: { orderId: mixed.order.id, type: 'SALE' } }) });
  const stockQuery = { where: { storeId_productId: { storeId: 'sh', productId: tea.id } } };
  const beforeFailure = await prisma.stock.findUnique(stockQuery);
  const prepared = await orders.prepareLines(input, 'sh');
  const lateId = await orders.createUnpaidOrder(input, 'sh', prepared);
  await orders.markPaymentFailed(lateId, '隔离审计注入失败');
  const restored = await prisma.stock.findUnique(stockQuery);
  await orders.markPaid(lateId, 'AUDIT-LATE-NO-EXTERNAL');
  const afterLate = await prisma.stock.findUnique(stockQuery);
  const lateOrder = await orders.getOrderRow(lateId);
  evidence('TX-03', { scenario: '失败释放库存后迟到成功消息恢复订单但未重新扣库', layer: 'service sequence+database', stockReturned: restored.grams === beforeFailure.grams, afterLateStockStillRestored: afterLate.grams === beforeFailure.grams, orderStatus: lateOrder.status, paymentStatus: lateOrder.paymentStatus });
  const partial = await orders.createOrder({ ...input, items: [{ ...input.items[0], qty: 2 }] });
  const partialLine = await prisma.orderItem.findFirst({ where: { orderId: partial.order.id } });
  const quoted = await orders.refundQuoteForOrder(partial.order.id, [{ itemId: partialLine.id, qty: 1 }]);
  await orders.executeRefund(staff, { order: quoted.order, quote: quoted.quote, reason: '隔离审计退款', prepared: false, approvalId: null, decidedBy: '隔离审计' });
  const cups = await prisma.orderUnit.findMany({ where: { orderId: partial.order.id } });
  for (const cup of cups) await orders.scanUnitById(staff, partial.order.id, cup.id);
  const remainingLine = await prisma.orderItem.findUnique({ where: { id: partialLine.id } });
  evidence('TX-05', { scenario: '两杯退款一杯后仍可将两杯全部扫码出餐', layer: 'service+database', paidRemainingQty: remainingLine.qty - remainingLine.refundedQty, refundedUnitsBeforeScan: cups.filter(x => x.status === 'refunded').length, scannedUnitsAfter: await prisma.orderUnit.count({ where: { orderId: partial.order.id, status: 'scanned' } }) });
  await prisma.userStore.deleteMany({ where: { userId: account.id } });
  await prisma.user.update({ where: { id: account.id }, data: { allStores: false } });
  const emptyScopeOrders = await http('GET', '/store/orders', undefined, login.body.token);
  evidence('SEC-04', { scenario: '员工保留订单查看权限但门店授权为空时仍读取到门店订单', layer: 'HTTP+database', httpStatus: emptyScopeOrders.status, authorizedStoreCount: await prisma.userStore.count({ where: { userId: account.id } }), leakedOrderCount: emptyScopeOrders.body.orders?.length ?? 0, includesSyntheticOrder: emptyScopeOrders.body.orders?.some(x => x.id === mixed.order.id) ?? false });
  evidence('BASELINE', { scenario: '临时库由正式迁移创建并用关闭交易的种子初始化', migrationDeploySucceeded: true, baseRestrictedToLoopback: true, testDataOnly: true });
})().then(async () => {
  if (app) await app.close();
  fs.rmSync(temp, { recursive: true, force: true });
  const report = { checkedAt: new Date().toISOString(), method: 'local HTTP + isolated SQLite + current built modules; external providers mock; no production access', results, cleanedUp: true };
  fs.writeFileSync(path.join(__dirname, 'local-probes.json'), JSON.stringify(report, null, 2) + '\n');
  console.log(JSON.stringify(report, null, 2));
}).catch(async err => {
  if (app) await app.close().catch(() => {});
  fs.rmSync(temp, { recursive: true, force: true });
  console.error('本地审计未完成：', err.message);
  process.exitCode = 1;
});
